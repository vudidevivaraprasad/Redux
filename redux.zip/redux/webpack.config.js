const path = require("path");
const htmlwenbpackplugin = require('html-webpack-plugin')

module.exports = {
  entry: "./src/index.js",
  output: {
    filename: "app.js",
    path: path.resolve(__dirname, "dist")
  },
  module:{
    rules:[
        {
            test:/\.js$/,
            exclude:/nodu_modules/,
            // use:{
            //     loader:'babel-loader',
            //     options:{
            //         presets:['@babel/preset-env']
            //     }
            // }
        }
    ]
},
  devServer: {
    static: {directory:path.join(__dirname, "dist")},
    port: 8000
  },
  mode: "development",
  plugins:[
    new htmlwenbpackplugin({
        template:'./src/index.html',
        filename:'index.html'
    })
  ]
};
