// import {toolkitStore,reduxStore} from './store'
import toolkitStore from './store'
import {addTodo,changeStatus,removeTodo} from './reducers/ToolkitTodosReducer'


//REDUX

// const unsubscribe = reduxStore.subscribe(()=> (console.log(reduxStore.getState())))

// toolkitStore.dispatch({
//     type:'addTodo',
//     payload:{
//         todo:{
//             name:'jkl',
//             completed:false
//         }
//     }
// })
// toolkitStore.dispatch({
//     type:'addTodo',
//     payload:{
//         todo:{
//             name:'mno',
//             completed:false
//         }
//     }
// })
// toolkitStore.dispatch({
//     type:'changeStatus',
//     payload:{
//         todoId:2
//     }
// })

// toolkitStore.dispatch({
//     type:'removeTodo',
//     payload:{
//         todoId:1
//     }
// })
//unsubscribe()
// console.log(reduxStore.getState())
// console.log(toolkitStore)


//REDUX TOOLKIT

// const unsubscribe = toolkitStore.subscribe(()=> (console.log(toolkitStore.getState())))

// if we place () ex:()=>({}) for the start of arrow function it will return that data automatically so I haven't used ()=>{}
// const createTodo = (name) => ({
//     name,
//     completed:false
// })


// store.dispatch({
//     type:'addTodo',
//     payload:{
//         todo:{
//             name:'abc',
//             completed:false
//         }
//     }
// })
//OR
// toolkitStore.dispatch(addTodo({
//     todo:{
//         name:'abc',
//         completed:false
//     }
// }))
//OR
// toolkitStore.dispatch(addTodo({todo:createTodo('abc')}))

// toolkitStore.dispatch(changeStatus({todoId:2}))
// toolkitStore.dispatch(removeTodo({todoId:3}))

// toolkitStore.dispatch(async()=>{
//     await setTimeout(()=>{
//         console.log('async function')
//     },1000)
// })
// console.log(toolkitStore)

// unsubscribe()