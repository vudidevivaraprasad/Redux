import {configureStore,getDefaultMiddleware} from '@reduxjs/toolkit'
import {loadTodos, changeTodo} from './reducers/ApiReducer'
import combineReducers from './reducers/reducer'
import func from './middleware/func'
import api from './middleware/api'

//the below store is using the combined reducer so if you want to perform all the operations just export this and dispatch action directly on this store
//the below store is the redux store
// const reduxStore = createStore(combineReducers,compose(applyMiddleware(logger("data")),window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__()))

//the below store is using the redux toolkit
const toolkitStore = configureStore({
    reducer:combineReducers,
    middleware:[...getDefaultMiddleware(),func,api]
})

toolkitStore.dispatch(loadTodos())
toolkitStore.dispatch(addTodo({"description":"todo"}))
toolkitStore.dispatch(changeTodo({id:2,resolved:true}))

// setTimeout(()=>{
//     toolkitStore.dispatch(loadTodos())
// },10000)
// export {reduxStore,toolkitStore}
export default toolkitStore