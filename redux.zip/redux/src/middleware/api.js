import axios from "axios";

const api = ({dispatch}) => next => action => {
    if(action.type !=='apicall/apicalling') return next(action);

    const {url,method,data,onprogress,onSuccess,onFailure} = action.payload;
    console.log(action.payload)
    if(onprogress) dispatch(onprogress())
    next(action)
    axios.request({
        baseURL:'http://localhost:9001/api',
        url,
        data,
        method
    }).then(response => { 
        console.log('success')
        if(onSuccess) dispatch(onSuccess(response.data)) })
      .catch(e => { 
        console.log('failed')
        if(onFailure) dispatch(onFailure(e.message)) })
}   

export default api