const logger = data=>state=>next=>action=>{
    console.log("data",data);
    console.log("state",state);
    console.log("next",next);
    console.log("action",action);
    next(action);
}

export default logger