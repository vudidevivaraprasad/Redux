let id=0

function reduxTodoReducer(state = [],action){
    // if(action.type === 'apiCallingSuccess'){
    //     return [...action.payload]
    // }
    if(action.type==='addTodo'){
        return [...state,{
            id:++id,
        ...action.payload.todo}]
    }
    else if(action.type==='removeTodo'){
        return state.filter((todo)=> todo.id!== action.payload.todoId)
    }
    else if(action.type==='changeStatus'){
        return state.map((todo)=>todo.id===action.payload.todoId? {...todo,completed:true}:todo)
    }
    else{
        return state
    }
}

export default reduxTodoReducer