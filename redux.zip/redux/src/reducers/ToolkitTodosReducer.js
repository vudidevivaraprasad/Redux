import {createSlice} from '@reduxjs/toolkit'
import {createAction} from '@reduxjs/toolkit'

export const addTodoAction = createAction('addTodo')
export const removeTodoAction = createAction('removeTodo')
export const changeStatusAction = createAction('changeStatus')

let id=0

const slice = createSlice({
    name:'todos',
    initialState:[],
    reducers:{
        addTodo:(state,action) => {
            state.push({
                id:++id,
            ...action.payload.todo
            })
        },
        removeTodo:(state,action) => {    
            state.splice(state.findIndex((todo)=>todo.id===action.payload.todoId),1)
        },
        changeStatus:(state,action) => {
            state[state.findIndex((todo)=>todo.id===action.payload.todoId)].completed=true
        }
    }
})

export const {addTodo,removeTodo,changeStatus} = slice.actions
export default slice.reducer

// export default createReducer([],{
//     [addTodoAction.type]:(state,action) => {
//         state.push({
//             id:++id,
//         ...action.payload.todo
//         })
//     },
//     [removeTodoAction.type]:(state,action) => {    
//         state.splice(state.findIndex((todo)=>todo.id===action.payload.todoId),1)
//     },
//     [changeStatusAction.type]:(state,action) => {
//         state[state.findIndex((todo)=>todo.id===action.payload.todoId)].completed=true
//     }
// })