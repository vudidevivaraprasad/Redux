import { createSlice,createAction } from "@reduxjs/toolkit";

const apiCalling = createAction('apicall/apicalling')

const slice = createSlice({
    name:'apicall',
    initialState:{
        todos:[],
        loading:false,
        LastFetch:null
    },
    reducers:{
        apiCallingSuccess:(state,action)=>{
            state.todos.push(...action.payload)
            state.LastFetch = Date.now()
            state.loading = false
        },
        apiCallingStarted:(state,action)=>{
            state.loading = true
        },
        apiCallingFailed:(state,action)=> {
            state.loading = false
        },
        apiAddTodo:(state,action)=>{
            state.todos.push(action.payload)
        },
        apiUpdateTodo:(state,action)=>{
            state.todos[state.todos.findIndex(todo => todo.id === action.payload.id)] = action.payload
            
        }
    }
})



const {apiCallingSuccess,apiCallingStarted,apiCallingFailed,apiAddTodo,apiUpdateTodo} = slice.actions

export const loadTodos = () => (dispatch,getState) => {
    const lastFetch = getState().apiReducer.LastFetch
    const timediff = (Date.now()-lastFetch)/(1000*60)
    // console.log('timediff',timediff)
    if(timediff < 10) return;
    dispatch(apiCalling({
        url:'/todo',
        method:'get',
        onSuccess:apiCallingSuccess,
        onFailure:apiCallingFailed,
        onprogress: apiCallingStarted,
    }))
}

export const addTodo = (todo) => (
    apiCalling({
        url:'/todo',
        method:'post',
        data: todo,
        onSuccess:apiAddTodo,
        onFailure:apiCallingFailed,
        onprogress: apiCallingStarted,
    })
)

export const changeTodo = (todo) => (
    apiCalling({
        url:'/todo/'+todo.id,
        method:'patch',
        data:{resolved:todo.resolved},
        onSuccess:apiUpdateTodo,
        onFailure:apiCallingFailed,
        onprogress:apiCallingStarted
    })
)

export default slice.reducer