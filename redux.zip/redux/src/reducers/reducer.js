import {combineReducers} from 'redux'
import ToolkitTodosReducer from './ToolkitTodosReducer'
import reduxTodoReducer from './reduxTodoReducer'
import ApiReducer from './ApiReducer'

export default combineReducers({
    reduxTodo: reduxTodoReducer,
    toolkitReducer: ToolkitTodosReducer,
    apiReducer: ApiReducer
})