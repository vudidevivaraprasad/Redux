const express = require("express");
const app = express();
const bodyParser = require("body-parser");
const cors = require("cors");

app.use(cors());
app.use(bodyParser.json());

const todos = [
  { id: 1, description: "Todo 1", resolved: true },
  { id: 2, description: "Todo 2" },
  { id: 3, description: "Todo 3" },
  { id: 4, description: "Todo 4" }
  ]

app.get("/api/todo", (req, res) => {
  res.json(todos);
});

app.post("/api/todo", (req, res) => {
  const todo = { id: Date.now(), resolved: false, ...req.body };
  todos.push(todo);

  res.json(todo);
});

app.patch("/api/todo/:id", (req, res) => {
  const index = todos.findIndex(todo => todo.id === parseInt(req.params.id));
  const todo = todos[index];
  if ("resolved" in req.body) todo.resolved = req.body.resolved;

  res.json(todo);
});

app.listen(9001, () => {
  console.log("Node server started on port 9001.");
});
